getAllProducts().then(() => {})

const lblDeveloper = document.querySelector('#lbl-developer');
const lblVersion = document.querySelector('#lbl-version');
const lblRelease = document.querySelector('#lbl-release');
const imgPhoto = document.querySelector('#lbl-photo');
const lblName = document.querySelector('#lbl-name');
const navTop = document.querySelector('#nav-top');
const navBot = document.querySelector('#nav-bot');

let products;
let current;

// получить все продукты при загрузке страницы
async function getAllProducts() {
    const response = await fetch("/api/products/", {
        method: "GET",
        headers: {"Accept": "application/json"}
    });
    if (response.ok === true) {
        products = await response.json();
        current = 0;
        getProduct(current);
    }
}

// получить предыдущий продукт
async function getPrevProduct() {
    if (current > 0) {
        current -= 1;
    } else {
        current = products.length - 1;
    }
    getProduct(current);
}

// получить следующий продукт
async function getNextProduct() {
    if (current < products.length - 1) {
        current += 1;
    } else {
        current = 0;
    }
    getProduct(current);
}

// получить продукт по индексу
function getProduct(e) {
    current = e;
    lblName.innerHTML = products[e].name;
    lblDeveloper.innerHTML = products[e].developer;
    lblVersion.innerHTML = products[e].version;
    lblRelease.innerHTML = products[e].release;
    imgPhoto.src = products[e].photo;

    navTop.innerHTML = "";
    navBot.innerHTML = "";
    for (let i = 0; i < products.length; i++) {

        if (i === current) {
            navTop.innerHTML += '<button type="button" style="text-decoration: underline;" ' +
                'onclick="getProduct(' + i + ')">' + products[i].name + '</button>'
        } else {
            navTop.innerHTML += '<button type="button" onclick="getProduct(' + i + ')">' +
                products[i].name + '</button>'
        }

        if (i === current) {
            navBot.innerHTML += '<button type="button" onclick="getProduct(' + i + ')">'
                + '<svg height="21px" width="30px"> <circle r="5" cx="15" cy="10" ' +
                'stroke="white" fill="white" ></circle></svg>'
                + '</button>'
        } else {
            navBot.innerHTML += '<button type="button" onclick="getProduct(' + i + ')">'
                + '<svg height="21px" width="30px"> <circle r="5" cx="15" cy="10" ' +
                'stroke="gray" fill="gray" ></circle></svg>'
                + '</button>'
        }

    }
}


