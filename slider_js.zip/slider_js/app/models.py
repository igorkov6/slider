from django.db import models


class Product(models.Model):

    name = models.CharField(max_length=200)
    developer = models.CharField(max_length=200)
    version = models.CharField(max_length=200)
    release = models.CharField(max_length=200)
    photo = models.ImageField(upload_to='products/', blank=True)
