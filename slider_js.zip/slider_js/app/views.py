from django.shortcuts import render, HttpResponse
from .models import Product
import json
from loguru import logger
from .serializers import ProductSerializer


def slider(request, pk=None):
    products = Product.objects.all()
    current = products[0]
    if pk is not None:
        current = Product.objects.get(pk=pk)

    return render(request, "app/slider.html", {'products': products, 'current': current})


def product(request, pk=None):
    p = Product.objects.get(pk=pk)
    logger.info(p)

    s = ProductSerializer(p)
    logger.info(s)

    d = json.dumps(s)
    logger.info(d)

    return HttpResponse('ok', status=200)
