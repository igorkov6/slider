from django.shortcuts import render
from .models import Product


def slider(request, pk=None):
    """
    Получить текущий продукт
    """

    # получить все продукты
    products = Product.objects.all()

    # текущий - первый продукт
    index = 0
    current = products[0]

    # По запросу POST - Команды слайдера - предыдущий / следующий. Отправлена форма.
    if request.method == 'POST':

        data = request.POST
        product_list = list(products)

        # найти предыдущий
        if 'prev' in data:
            current_id = data['prev']
            for prod in product_list:
                if int(prod.id) == int(current_id):
                    index = product_list.index(prod)
                    if index > 0:
                        index -= 1
                    else:
                        index = len(product_list)-1
                    break

        # найти следующий
        elif 'next' in data:
            current_id = data['next']
            for prod in product_list:
                if int(prod.id) == int(current_id):
                    index = product_list.index(prod)
                    if index < len(product_list) - 1:
                        index += 1
                    else:
                        index = 0
                    break

        # получить текущий продукт
        current = Product.objects.get(pk=product_list[index].id)

    # По запросу GET - непосредственный выбор продукта - переход по ссылке.
    else:

        if pk is not None:
            # текущий продукт по запросу
            current = Product.objects.get(pk=pk)

    return render(request, "app/slider.html", {'products': products, 'current': current})
